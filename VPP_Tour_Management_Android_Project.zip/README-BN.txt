VPP Tour Management Android Project

এটি Android Studio-এর জন্য তৈরি একটি WebView-based Android project।
ফিচার: Dashboard, Tour, Booking, Income/Expense, Profit/Loss, Due এবং Report।

APK বানাতে:
1. Android Studio-তে এই project folder খুলুন।
2. Gradle sync শেষ হতে দিন।
3. Build > Build APK(s) নির্বাচন করুন।
4. তৈরি APK ফোনে ইনস্টল করুন।

নোট: এই পরিবেশে Android SDK/Gradle build tool না থাকায় সরাসরি APK compile করা সম্ভব হয়নি; source project প্রস্তুত করা হয়েছে।
